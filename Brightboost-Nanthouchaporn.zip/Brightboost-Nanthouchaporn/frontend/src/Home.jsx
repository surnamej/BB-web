import React, { useEffect, useState } from 'react';
import Footer from './components/Footer';
import Menu from './components/Menu';
import { useNavigate } from 'react-router-dom';

function HomePage(props) {

    const [loading, setLoading] = useState(true);
    const clickHandle = () => {
        navigate('/course');
    }

    const navigate = useNavigate();
    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
        navigate('/welcome');
        } else {
        if (sessionId != props.userdata.userId) {
            fetch("http://localhost:8081/api/get_userdata_by_id/" + sessionId)
            .then(res => res.json())
            .then(data => {
            if (data.length == 1) {
                props.setUserdata({
                    ...props.userdata,
                    userId: data[0].userId,
                    role: data[0].userRole,
                    fname: data[0].firstName,
                    mname: data[0].middleName,
                    lname: data[0].lastName
                });
            }
            })
        }
        setLoading(false);
        }
        if (props.userdata.role == "tutor") navigate("/course");
        if (props.userdata.role == "admin") navigate("/user_display");
    }, [])

    useEffect(() => {

    }, [loading])

    return (
        <div>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            <main className="home-main">
                <h1 className="home-h1">Welcome to BrightBoost</h1>
                <p className="home-totle">Your Path to Success Starts Here</p>

                <section className="section-students">
                <h2 className="home-h2">For Students</h2>
                <p>Unlock your full potential with BrightBoost. Find the perfect tutor to help you excel in your studies.</p>
                <ul>
                    <li>Search for qualified tutors in various subjects.</li>
                    <li>Schedule one-on-one tutoring sessions.</li>
                    <li>Get personalized study plans and guidance.</li>
                </ul>
                <button onClick={clickHandle}>Ask a question NOW</button>
                </section>
            </main>
            <Footer />
        </div>
    );
}

export default HomePage;