import { useEffect, useState } from 'react'
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import Footer from "./components/Footer";
import Menu from "./components/Menu";
import { useNavigate, useParams } from 'react-router-dom';

function TutorSubmitAnswer(props) {
    const [loading, setLoading] = useState(true)
    const params = useParams();
    const navigate = useNavigate();
    const [question, setQuestion] = useState({});
    const [text, setText] = useState("");

    const modules = {
        toolbar: [
          [{ header: [1, 2, 3, 4 ,5, 6, false] }],
          [{ font: [] }],
          [{ size: [] }],
          ["bold", "italic", "underline", "strike", "blockquote"],
          [{ script: "sub" }, { script: "super" }],
          [ 
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
          ],
      ],
    };

    const func = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/question_by_id/" + params.question)
        .then(res => res.json())
        .then(data => {

            setQuestion(data[0]);
            setLoading(false);
        })
    }

    const handleClick = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/update/answering/" + params.question + "/" + encodeURIComponent(text))
        .then(() => {
            navigate("/course/" + params.subject + "/" + question.sessionId)
        })
    }

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                    if (data.length == 1) {
                        props.setUserdata({
                            ...props.userdata,
                            userId: data[0].userId,
                            role: data[0].userRole,
                            fname: data[0].firstName,
                            mname: data[0].middleName,
                            lname: data[0].lastName
                        });
                    }
                })
            }
            func();
        }
        if (props.userdata.role == "admin") navigate("/data");
    }, [])

    useEffect(() => {

    }, [loading])
    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            {
                !loading ?
                <>
                    <div className="subject">
                        <h2>Subject ID</h2>
                        <p className="subjectText">{question.questionId}</p>
                    </div>

                    <div className="question">
                        <h2>Question</h2>
                        <div className='questionText' dangerouslySetInnerHTML={{__html: decodeURIComponent(question.questionText)}}/>
                    </div>

                    <div className="editor">You can write an answer here<br />
                        <ReactQuill 
                            theme = "snow"
                            className="editor-input"
                            onChange={e => setText(e)}
                            modules={modules}
                            placeholder='Type your answer here...'
                        />
                    </div>
                    <button className="attendance-sendButton" onClick={handleClick}>Send</button>
                </>
                :
                <div />
            }
            <Footer />
        </>
      )
}

export default TutorSubmitAnswer;