import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Form } from 'react-bootstrap';
import './App.css';
import Footer from './components/Footer';
import Menu from './components/Menu';

function Course(props) {
    const [subjects, setSubjects] = useState([]);
    const [sessions, setSessions] = useState([]);
    const [selectedSession, selectSession] = useState("");
    const [selectedSubject, selectSubject] = useState("");
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [showAlert, setShowAlert] = useState(false); // State for displaying the alert
    const navigate = useNavigate();

    // Function to handle displaying the alert
    const displayAlert = () => {
        setShowAlert(true);
        setTimeout(() => {
            setShowAlert(false);
        }, 3000); // Hide the alert after 3 seconds
    };

    const handleCourseClick = (subjectId, userId) => {
        selectSubject(subjectId);
        if (props.userdata.role == "tutor") {
            fetch("http://localhost:8081/api/session/" + subjectId + "/" + userId)
            .then(res => res.json())
            .then(data => {
                console.log(data)
                if (data.length > 0) navigate('/course/' + subjectId + "/" + data[0].sessionId);
                else {
                    // No available subjects, display the alert
                    displayAlert();
                }
            })
        } else {
            fetch("http://localhost:8081/api/session/" + subjectId)
            .then(res => res.json())
            .then(data => {
                if (data.length == 1) {
                    navigate("/course/" + subjectId + "/" + data[0].sessionId);
                } else if (data.length > 1) {
                    selectSession(data[0].sessionId);
                    setShowModal(true);
                    setSessions(data);
                } else {
                    // No available subjects, display the alert
                    displayAlert();
                }
            })
        }
    }

    const func = (role, id) => {
        switch (role) {
            case "tutor":
                fetch("http://localhost:8081/api/course_by_tutor/" + id)
                .then(res => res.json())
                .then(data => {
                    setSubjects(data);
                    setLoading(false);
                })
                break;
            case "student":
                fetch("http://localhost:8081/api/course")
                .then(res => res.json())
                .then(data => {
                    setSubjects(data);
                    setLoading(false);
                })
                break;
        }
    }

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch("http://localhost:8081/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                if (data.length == 1) {
                    props.setUserdata({
                        ...props.userdata,
                        userId: data[0].userId,
                        role: data[0].userRole,
                        fname: data[0].firstName,
                        mname: data[0].middleName,
                        lname: data[0].lastName
                    });
                    func(data[0].userRole, data[0].userId);
                }
            })
            } else {
                func(props.userdata.role, props.userdata.userId);
            }
        }
        if (props.userdata.role == "admin") navigate("/user_display");
    }, [])
  
    useEffect(() => {

    }, [loading, showModal])

    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            {/* Alert component */}
            {showAlert && (
                <div className="alert alert-danger">
                    No available subjects. Please try again later.
                </div>
            )}
            {
                !loading ? 
                <div className='course-container'>
                    {
                        subjects.map(s => (
                            <div className='course-block' key={s.subjectId} onClick={() => handleCourseClick(s.subjectId, props.userdata.userId)}>
                                <button className='course-subjectButton'>
                                    {s.subjectName}
                                </button>
                            </div>
                        ))
                    }

                    {
                        props.userdata.role == "student" && showModal && (
                            <div className="session-modal">
                                <div className="session-modal-content">
                                    <h2>Select session for</h2>
                                    {
                                        sessions.map((session, index) => (
                                            <label key={index}>
                                                <input 
                                                    type='radio' 
                                                    value={session.sessionId} 
                                                    checked={session.sessionId == selectedSession}
                                                    onChange={(e) => selectSession(e.target.value)}
                                                />
                                                {session.sessionId}
                                            </label>
                                        ))
                                    }
                                    <button className="question-sendButton" onClick = {() => navigate("/course/"+selectedSubject+"/"+selectedSession)} >Submit</button>
                                    <button className="question-sendButton" onClick={() => setShowModal(false)}>Close</button>
                                </div>
                            </div>
                        )
                    }
                </div>
                :
                <div />
            }
            <Footer />
        </>
    );
}

export default Course;