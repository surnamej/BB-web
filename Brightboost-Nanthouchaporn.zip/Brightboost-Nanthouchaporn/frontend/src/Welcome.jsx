import { useNavigate } from "react-router-dom";

function Welcome() {
    const navigate = useNavigate();
    const startClickHandle = () => {
        navigate('/login');
    }

    return (
        <main className="welcome-bg container-fluid d-flex flex-column justify-content-center align-items-center p-0 m-0">
            <h1 className="welcome-h1 display-4 text-center mb-4">
                Welcome to BrightBoost
            </h1>
            <p className="welcome-p lead text-center">
                Elevate your learning experience with BrightBoost, where students, tutors, and administrators<br />come together to shape a brighter future.
            </p>
            <div className="mt-4">
                <a href= "/login" className="welbom-btn btn btn-light btn-lg">
                    Get Started
                </a>
            </div>
        </main>
    );
}

export default Welcome;