import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Menu from "./components/Menu";
import Footer from "./components/Footer";

function Row(props) {
    const navigate = useNavigate();
    const params = useParams();

    const questionClick = () => {
        if (props.userdata.role == "tutor" && props.answer == null) navigate("/answer/" + params.subject + "/" + props.id)
        console.log("/answer/" + params.subject + "/" + props.id);
    }

    return (
        <tr onClick={questionClick}>
            <td className="queueData">{props.queue}</td>
            <td className="subjectData">{props.student}</td>
            <td className="questionData">
                <div dangerouslySetInnerHTML={{__html: decodeURIComponent(props.question)}} />
            </td>
            <td className="answerData"> 
                {
                    props.answer == null ?
                    
                    <></>
                    :
                    <div dangerouslySetInnerHTML={{__html: decodeURIComponent(props.answer)}}/>
                }
                <div />
            </td>
        </tr>
    )
}

function Table(props) {

    return (
        <table>
            <thead>
            <tr>
                <th className='queueTable'>Queue</th>
                <th className='subjectTable'>Student</th>
                <th className='questionTable'>Question</th>
                <th className="answerTable">Answer</th>
            </tr>
            </thead>
            <tbody>
            {
                props.question.length === 0 ? (
                    <tr>
                        <td className="queueData">-</td>
                        <td className="subjectData">-</td>
                        <td className="questionData">-</td>
                        <td className="answerData">-</td>
                    </tr>
            ) : (
                props.question.map((row, index) => (
                    <Row 
                        key={row.questionId} 
                        id={row.questionId} 
                        userdata={props.userdata} 
                        queue={index + 1} 
                        student={row.studentId} 
                        question={row.questionText} 
                        answer={row.answerText}
                    />
                ))
            )}
            </tbody>
        </table>
      );
}

function QuestionList(props) {

    const params = useParams();
    const [question, setQuestion] = useState([]);
    const [loading, setLoading] = useState(true);
    const [studentCount, setStudentCount] = useState(0); // State to store the number of students
    const navigate = useNavigate();

    const updateStudentCount = () => {
        // You can perform an action here with the updated studentCount
        fetch(import.meta.env.VITE_BACKEND + "/api/attendance/" + studentCount + "/" + params.session)
        .then(res => res.json())
        .then(data => {
            console.log(`Number of students: ${studentCount}`);
        })
    };

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                    if (data.length == 1) {
                        props.setUserdata({
                            ...props.userdata,
                            userId: data[0].userId,
                            role: data[0].userRole,
                            fname: data[0].firstName,
                            mname: data[0].middleName,
                            lname: data[0].lastName
                        });
                    }
                })
            }
            fetch(import.meta.env.VITE_BACKEND + "/api/course_check/" + params.subject)
            .then(res => res.json())
            .then(data => {
                if (data[0].count == 0) navigate("/course");
                fetch(import.meta.env.VITE_BACKEND + "/api/question_by_session/" + params.session)
                .then(res => res.json())
                .then(data => {
                    setQuestion(data);
                    setLoading(false);
                })
            })
        }
        if (props.userdata.role == "admin") navigate("/user_display");
    }, [])

    useEffect(() => {

    }, [loading])

    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            <div className = "App">
                {
                    loading ? 
                    <div />
                    :
                    <>
                        {
                            props.userdata.role == "student" ?
                            <div className="s-t-getQueue">
                                <button 
                                    className="question-addButton" 
                                    onClick={() => navigate("/question/" + params.subject + "/" + params.session)}
                                >Add</button>
                            </div>
                            :
                            <></> 
                        },
                        {
                            props.userdata.role == "tutor" ?
                            <div className="s-t-getQueue">
                                
                                <span>Number of Students:</span>
                                <input
                                    type="number"
                                    value={studentCount}
                                    onChange={(e) => setStudentCount(e.target.value)}
                                />
                                <button className="question-sendButton" onClick={updateStudentCount}>Submit</button>
                            </div>
                            
                            :
                            <></> 
                        }
                        <Table question={question} userdata={props.userdata}/>
                    </>
                }
            </div>
            <Footer />
        </>
    )
}

export default QuestionList;