import { useEffect, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Welcome from './Welcome';
import Login from './Login';
import Home from './Home';
import Profile from './Profile';
import Course from './Course';
import QuestionList from './QuestionList';
import StudentAskQuestion from './StudentAskQuestion';
import TutorSubmitAnswer from './TutorSubmitAnswer';
import DisplayData from './DisplayData';
import FormPage from './FormPage';
import Dashboard from './Dashboard';
import Timetable from './Timetable';

function App() {
  const [userdata, setUserdata] = useState({
    userId: "",
    role: "",
    fname: "",
    mname: "",
    lname: ""
  });

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/welcome' element={<Welcome />} />
          <Route path='/login' element={<Login userdata={userdata} setUserdata={setUserdata} />} />
          <Route path='/home' element={<Home userdata={userdata} setUserdata={setUserdata} />} />
          <Route path='/profile' element={<Profile userdata={userdata} setUserdata={setUserdata} />} />
          <Route path='/course' element={<Course userdata={userdata} setUserdata={setUserdata} />} />
          <Route path='/course/:subject/:session' element={<QuestionList userdata={userdata} setUserdata={setUserdata} />}/>
          <Route path='/question/:subject/:session' element={<StudentAskQuestion userdata={userdata} setUserdata={setUserdata}/>} />
          <Route path='/answer/:subject/:question' element={<TutorSubmitAnswer userdata={userdata} setUserdata={setUserdata} />} />
          <Route path='/data' element={<DisplayData userdata={userdata} setUserdata={setUserdata} />} />
          <Route path='/formpage' element={<FormPage userdata={userdata} setUserdata={setUserdata}/>} />
          <Route path='/dashboard' element={<Dashboard  userdata={userdata} setUserdata={setUserdata}/>} />
          <Route path='/schedule' element={<Timetable userdata={userdata} setUserdata={setUserdata} />}/>
          <Route path='*' element={<Navigate to='/welcome'/>} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
