import { useEffect, useState } from "react";
import Menu from "./components/Menu";
import Footer from "./components/Footer";

function DisplayData(props) {
    const [loading, setLoading] = useState(true);
    const [users, setUsers] = useState([]);
    const [sessions, setSessions] = useState([]);
    const [questions, setQuestions] = useState([]);

    const [showUserTable, setShowUserTable] = useState(false);
    const [showSessionTable, setShowSessionTable] = useState(false);
    const [showQuestionTable, setShowQuestionTable] = useState(false);

    const [userSearch, setUserSearch] = useState('');
    const [sessionSearch, setSessionSearch] = useState('');
    const [questionSearch, setQuestionSearch] = useState('');

    const func = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/display/user_info")
        .then(res => res.json())
        .then(data => {
            setUsers(data);
            fetch(import.meta.env.VITE_BACKEND + "/api/display/session")
            .then(res => res.json())
            .then(data => {
                setSessions(data);
                fetch(import.meta.env.VITE_BACKEND + "/api/display/question")
                .then(res => res.json())
                .then(data => {
                    setQuestions(data);
                    setLoading(false);
                })
            })
        })
    }

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                    if (data.length == 1) {
                        props.setUserdata({
                            ...props.userdata,
                            userId: data[0].userId,
                            role: data[0].userRole,
                            fname: data[0].firstName,
                            mname: data[0].middleName,
                            lname: data[0].lastName
                        });
                    }
                })
            } 
            func();
        }
        if (props.userdata.role == "student") navigate("/home");
        if (props.userdata.role == "tutor") navigate("/course");
    }, [])
  
    useEffect(() => {

    }, [loading])

    const filterTable = (table, value) => table.filter(row => {
        for (const key in row) {
            if (typeof row[key] === 'string' && row[key].toLowerCase().includes(value.toLowerCase()))
                return true;
        }
    })

    const timePattern = (sec) => {
        const min = Math.floor(sec / 60);
        const remainSec = sec % 60;

        return `${min}:${remainSec.toString().padStart(2, '0')}`;
    }

    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            {
                !loading ?
                <div className="data-display">
                    {/* User Information Table */}
                    <h2>User Information
                        <button className="table-button" onClick={() => setShowUserTable(!showUserTable)}>{showUserTable ? 'Close Table' : 'Show Table'}</button>
                    </h2>
                    {showUserTable && (
                        <>
                            <input
                                type="text"
                                placeholder="Search Users..."
                                value={userSearch}
                                onChange={(e) => setUserSearch(e.target.value)}
                            />
                            <table>
                                <thead className="data-display-head">
                                    <tr>
                                        <th>UserID</th>
                                        <th>First Name</th>
                                        <th>Middle Name</th>
                                        <th>Last Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        filterTable(users, userSearch).map(user => (
                                            <tr key={user.userId}>
                                                <td>{user.userId}</td>
                                                <td>{user.firstName}</td>
                                                <td>{user.middleName}</td>
                                                <td>{user.lastName}</td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                        </>
                    )}
        
                    {/* Session Table */}
                    <h2>
                        Session
                        <button
                            className="table-button"
                            onClick={() => setShowSessionTable(!showSessionTable)}>
                            {showSessionTable ? "Close Table" : "Show Table"}
                        </button>
                    </h2>
                    {showSessionTable && (
                        <>
                            <input
                                type="text"
                                placeholder="Search Sessions..."
                                value={sessionSearch}
                                onChange={(e) => setSessionSearch(e.target.value)}
                            />
                            <table>
                            <thead>
                                <tr>
                                    <th>Session ID</th>
                                    <th>Tutor</th>
                                    <th>Attendance No.</th>
                                    <th>No. of Questions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    filterTable(sessions, sessionSearch).map(session => (
                                        <tr key={session.sessionId}>
                                            <td>{session.sessionId}</td>
                                            <td>{session.tutors}</td>
                                            <td>{session.attendance}</td>
                                            <td>{session.question_count}</td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                        <br></br>
                        </>
                    )}
        
                    {/* Questions Table */}
                    <h2>
                        Question Table
                        <button
                            className="table-button"
                            onClick={() => setShowQuestionTable(!showQuestionTable)}>
                            {showQuestionTable ? "Close Table" : "Show Table"}
                        </button>
                    </h2>
                    {showQuestionTable && (
                        <>
                            <input
                                type="text"
                                placeholder="Search Questions..."
                                value={questionSearch}
                                onChange={(e) => setQuestionSearch(e.target.value)}
                            />
                            <table>
                            <thead>
                                <tr>
                                    <th>Session ID</th>
                                    <th>Question Content</th>
                                    <th>Answer</th>
                                    <th>Tutor ID</th>
                                    <th>Time Difference in min</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    filterTable(questions, questionSearch).map((question, index) => (
                                        <tr key={index}>
                                            <td>{question.sessionId}</td>
                                            <td dangerouslySetInnerHTML={{__html: decodeURIComponent(question.questionText)}} />
                                            <td dangerouslySetInnerHTML={{__html: decodeURIComponent(question.answerText)}} />
                                            <td>{question.tutorId}</td>
                                            <td>{timePattern(question.time)} minute</td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                        </>
                    )}
                <br />
                </div>
                :
                <div />
            }
            <Footer />
        </>
    );
}

export default DisplayData;