import Image from 'react-bootstrap/Image';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import imgLogo from "../assets/school-logo.png";
import { useNavigate } from 'react-router-dom';

function Menu(props) {
  const navigate = useNavigate();
  const logoutHandle = () => {
    props.setUserdata({
      ...props.userdata,
      userId: "",
      role: "",
      fname: "",
      mname: "",
      lname: ""
    });
    sessionStorage.removeItem("userId");
    navigate('/welcome');
  }
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container fluid>
        <Navbar.Brand>
          {<Image src={imgLogo} alt='companyphoto' width={200} height={25} />}
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll" className="justify-content-end">
          {
            props.userdata.role == "student" ?
            <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: '100px' }} navbarScroll>
              <Nav.Link onClick={() => navigate('/home')}>Home</Nav.Link>
              <Nav.Link onClick={() => navigate('/profile')}>Profile</Nav.Link>
              <Nav.Link onClick={() => navigate('/course')}>Course</Nav.Link>
              <Nav.Link onClick={() => navigate('/schedule')}>Tutor Timetable</Nav.Link>
              <Nav.Link onClick={logoutHandle}>Log out</Nav.Link>
            </Nav>
            : props.userdata.role == "tutor" ?
            <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: '100px' }} navbarScroll>
              <Nav.Link onClick={() => navigate('/profile')}>Profile</Nav.Link>
              <Nav.Link onClick={() => navigate('/course')}>Course</Nav.Link>
              <Nav.Link onClick={() => navigate('/schedule')}>Tutor Timetable</Nav.Link>
              <Nav.Link onClick={logoutHandle}>Log out</Nav.Link>
            </Nav>
            : props.userdata.role == "admin" ?
            <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: '100px' }} navbarScroll>
              <Nav.Link onClick={() => navigate('/data')}>Data</Nav.Link>
              <Nav.Link onClick={() => navigate('/formpage')}>Form</Nav.Link>
              <Nav.Link onClick={() => navigate('/dashboard')}>Dashboard</Nav.Link>
              <Nav.Link onClick={() => navigate('/schedule')}>Schedule</Nav.Link>
              <Nav.Link onClick={logoutHandle}>Log out</Nav.Link>
            </Nav>
            :
            <></>
          }
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Menu;