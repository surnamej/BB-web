import '../App.css'

function Footer() {
    return (
        <footer>
            <div>
                <p className="footer">
                    &copy; {new Date().getFullYear()} BrightBoost. All rights reserved.
                </p>
            </div>
            {/*<p className="footer">Contact: <a href="mailto:104520434@student.swin.edu.au">Nanthouchaporn</a></p> - we can put link to ergent report later (optional)*/}
        </footer>
    )
}

export default Footer