import React, { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import './App.css';
import Form from 'react-bootstrap/Form';
import FormCheck from 'react-bootstrap/FormCheck'
import Footer from './components/Footer';
import Menu from './components/Menu';

function AdminTimetable(props) {
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    const sessionId = sessionStorage.getItem("userId");
    if (sessionId == null) {
      navigate('/welcome');
    } else {
      if (sessionId != props.userdata.userId) {
        fetch("http://localhost:8081/api/get_userdata_by_id/" + sessionId)
        .then(res => res.json())
        .then(data => {
          if (data.length == 1) {
            props.setUserdata({
                ...props.userdata,
                userId: data[0].userId,
                role: data[0].userRole,
                fname: data[0].firstName,
                mname: data[0].middleName,
                lname: data[0].lastName
            });
            setLoading(false);
          }
        })
      }
      setLoading(false);
    }
    if (props.userdata.role == "admin") navigate("/data");
  }, [])

  useEffect(() => {

  }, [loading])

  const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const subjects = ["Math", "English", "Science"];
  const slots = ["slot1", "slot2", "slot3"];

  const [tableData, setTableData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCell, setSelectedCell] = useState(null);
  const [formData, setFormData] = useState({ tutor: [] });
  const tutors = ["Tutor A", "Tutor B", "Tutor C"];
  const [isEditing, setIsEditing] = useState(false);

  const openModal = (cell, editing = false) => {
    setIsModalOpen(true);
    setSelectedCell(cell);
    setIsEditing(editing);
    if (editing) {
      const selectedModule = tableData.find(
        (module) => module.day === cell.day && module.subject === cell.subject && module.slot === cell.slot
      );
      if (selectedModule) {
        setFormData({
          tutor: selectedModule.tutor,
        });
      } else {
        setFormData({ tutor: "" });
      }
    } else {
      setFormData({ tutor: "" });
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCell(null);
    setFormData({ tutor: "" });
    setIsEditing(false);
  };

  const handleSave = () => {
    const { day, subject, slot } = selectedCell;

    if (isEditing) {
      const updatedData = tableData.map((module) => {
        if (module.day === day && module.subject === subject && module.slot === slot) {
          return {
            day,
            subject,
            slot,
            tutor: formData.tutor,
          };
        }
        return module;
      });
      setTableData(updatedData);
    } else {
      setTableData((prevTableData) => [
        ...prevTableData,
        {
          day,
          subject,
          slot,
          tutor: formData.tutor,
        },
      ]);
    }

    closeModal();
  };

  return (
    <>
      <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
      {
        !loading ?
        <div>
          <table className="timetable">
            <thead>
              <tr>
                <th></th>
                {daysOfWeek.map((day) => <th key={day}>{day}</th>)}
              </tr>
            </thead>
            <tbody>
              {subjects.map((subject, rowIndex) => (
                slots.map((slot, slotIndex) => (
                  <tr key={`${subject}-${slot}`}>
                    {slotIndex === 0 && <td rowSpan="3">{subject}</td>}
                    {daysOfWeek.map((day, colIndex) => (
                      <td key={day}>
                        {(() => {
                          const cellModule = tableData.find(module =>
                            module.day === day &&
                            module.subject === subject &&
                            module.slot === slot
                          );
                          if (cellModule) {
                            return (
                              <div key={`${day}-${subject}-${slot}`} className="cell-data">
                                {console.log(cellModule.tutor)}
                                <p>{cellModule.tutor}</p>
                                <button className="edit-button" onClick={() => openModal({ day, subject, slot }, true)}>
                                  Edit
                                </button>
                              </div>
                            );
                          }
                          return (
                            <button className="insert-button" onClick={() => openModal({ day, subject, slot })}>
                              Insert
                            </button>
                          );
                        })()}
                      </td>
                    ))}
                  </tr>
                ))
              ))}
            </tbody>
          </table>

          {isModalOpen && (
            <div className="modal">
              <div className="modal-content">
                <h2>{isEditing ? "Edit Tutor" : "Insert Tutor"}</h2>
                <label>Day: {selectedCell.day}</label><br />
                <label>Subject: {selectedCell.subject}</label><br />
                <label>Slot: {selectedCell.slot}</label><br />
                <label>Tutor:</label><br />
                {/*<select
                  className="select-box"
                  onChange={(e) => setFormData({ ...formData, tutor: e.target.value })}
                  value={formData.tutor}
                >
                  <option value="">Select Tutor</option>
                  {tutors.map((tutor) => (
                    <option key={tutor} value={tutor}>
                      {tutor}
                    </option>
                  ))}
                </select>*/}
                {/*<Form>
                  {tutors.map((tutor) => (
                    <Form.Check
                      key={tutor}
                      type="checkbox"
                      id={tutor}
                      label={tutor}
                      checked={formData.tutor.includes(tutor)}
                      onChange={(e) => {
                        const selectedTutors = formData.tutor.slice(); // Make a copy of the array
                        if (e.target.checked) {
                          selectedTutors.push(tutor);
                        } else {
                          const index = selectedTutors.indexOf(tutor);
                          if (index !== -1) {
                            selectedTutors.splice(index, 1);
                          }
                        }
                        setFormData({ tutor: selectedTutors });
                      }}
                    />
                  ))}
                </Form>*/}
                <Form>
                    { tutors.map((tutor) => (
                        <Form.Check // prettier-ignore
                            key={tutor}
                            value={tutor}
                            id={tutor}
                            label={tutor}
                            onChange={(e) => {
                                const selectedTutors = formData.tutor; // Make a copy of the array
                                if (e.target.checked) {
                                    selectedTutors.push(tutor);
                                } else {
                                    const index = selectedTutors.indexOf(tutor);
                                    if (index !== -1) {
                                    selectedTutors.splice(index, 1);
                                    }
                                }
                                setFormData({ tutor: selectedTutors });
                                }}
                        />
                    ))}
                </Form>
                <button className="save-button" onClick={handleSave}>Save</button>
              </div>
            </div>
          )}
        </div>
        :
        <div />
      }
      <Footer />
    </> 
  );
}

export default AdminTimetable;
