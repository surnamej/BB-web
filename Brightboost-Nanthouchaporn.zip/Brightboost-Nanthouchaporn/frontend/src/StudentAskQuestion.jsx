import { useEffect, useState } from 'react'
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { useNavigate, useParams } from 'react-router-dom';
import Menu from './components/Menu';
import Footer from './components/Footer';

const modules = {
    toolbar: [
        [{ header: [1, 2, 3, 4 ,5, 6, false] }],
        [{ font: [] }],
        [{ size: [] }],
        ["bold", "italic", "underline", "strike", "blockquote"],
        [{ script: "sub" }, { script: "super" }],
        [ 
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
        ]
    ]
};

function StudentAskQuestion(props) {
    const params = useParams();
    const [loading, setLoading] = useState(true);
    const [tutor, setTutor] = useState([]);
    const [selectedTutor, selectTutor] = useState("");
    const [text, setText] = useState("");
    const navigate = useNavigate();

    const func = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/tutor_in_session/" + params.session)
        .then(res => res.json())
        .then(data => {
            setTutor(data);
            selectTutor(data[0].userId);
            setLoading(false);
        })
    }

    const handleClick = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/insert_question/" + encodeURIComponent(text) + "/" + props.userdata.userId + "/" + selectedTutor + "/" + params.session)
        .then(() => {
            navigate("/course/" + params.subject + "/" + params.session)
        })
    }

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                    if (data.length == 1) {
                        props.setUserdata({
                            ...props.userdata,
                            userId: data[0].userId,
                            role: data[0].userRole,
                            fname: data[0].firstName,
                            mname: data[0].middleName,
                            lname: data[0].lastName
                        });
                    }
                })
            }
            func();
        }
        if (props.userdata.role == "tutor") navigate("/course");
        if (props.userdata.role == "admin") navigate("/data");
    }, [])

    useEffect(() => {

    }, [loading])
    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            {
                loading ? 
                <div />
                :
                <>
                    <div className="subject">
                        <h2>Subject ID</h2>
                        <p className="subjectText">{params.subject}</p>
                    </div>
            
                    <div>
                        <div> Choose tutor for your question
                            <select className="select-box" onChange={e => selectTutor(e.target.value)}>
                                {
                                    tutor.map((t, index) => (
                                        <option key={index} value={t.userId}>{t.name}</option>
                                    ))
                                }
                            </select>
                        </div>
                    </div>
            
                    <div className="editor">You can write a specific question here<br />
                        <ReactQuill 
                            theme = "snow" 
                            className="editor-input"
                            onChange={e => setText(e)}
                            modules={modules}
                            placeholder='Type your question here...'
                        />
                    </div>
            
                    <button className="question-sendButton" onClick={handleClick}>Send</button>
                </>
            }
            <Footer />
        </>
    )
}

export default StudentAskQuestion;