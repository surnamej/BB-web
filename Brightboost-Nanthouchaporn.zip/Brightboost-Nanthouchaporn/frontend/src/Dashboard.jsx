import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BarChart from './components/BarChart';
import Footer from './components/Footer';
import Menu from './components/Menu';
 
const Dashboard = (props) => {
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const [general, setGeneral] = useState({});
    const [subjects, setSubjects] = useState([]);

    const func = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/dashboard/general")
        .then(res => res.json())
        .then(data => {
            console.log(data)
            setGeneral(data[0]);
            fetch(import.meta.env.VITE_BACKEND + "/api/dashboard/monthly")
            .then(res => res.json())
            .then(data => {
                setSubjects(data);
                setLoading(false);
            })
        })
    }

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                    if (data.length == 1) {
                        props.setUserdata({
                            ...props.userdata,
                            userId: data[0].userId,
                            role: data[0].userRole,
                            fname: data[0].firstName,
                            mname: data[0].middleName,
                            lname: data[0].lastName
                        });
                    }
                })
            }
            func();
        }
        if (props.userdata.role == "student") navigate("/home");
        if (props.userdata.role == "tutor") navigate("/course");
    }, [])

    useEffect(() => {

    }, [loading])

    // State for various dashboard data
    const [enrolledStudents, setEnrolledStudents] = useState(0);
    const [totalQuestions, setTotalQuestions] = useState(0);
    const [answeredQuestions, setAnsweredQuestions] = useState(0);
    const [percentageAnswered, setPercentageAnswered] = useState(0);
    // State for attendance data
    const [attendanceData, setAttendanceData] = useState([]);
    
    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            {
                !loading ?
                <div>
                    <h1>Dashboard</h1>
                    <div className="dashboard-cards">
                        <div className="dashboard-card">
                            <h2>Total Enrolled Students</h2>
                            <p>{general.students}</p>
                        </div>
                        <div className="dashboard-card">
                            <h2>Total Questions Asked</h2>
                            <p>{general.questions}</p>
                        </div>
                        <div className="dashboard-card">
                            <h2>Answered Questions</h2>
                        <p>{general.answers} ({(general.answers * 100 / general.questions).toFixed(2)}%)</p>
                        </div>
                    </div>
                    <div style={{ marginTop: '20px' }}>
                        <h2>Monthly Attendance per Subject</h2>
                        <BarChart data={subjects} />
                    </div>
                </div>
                :
                <div />
            }
            <Footer />
        </>
    );
};
 
export default Dashboard;