import React, { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import './App.css';
import Form from 'react-bootstrap/Form';
import FormCheck from 'react-bootstrap/FormCheck'
import Footer from './components/Footer';
import Menu from './components/Menu';

function Timetable(props) {
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const [subjects, setSubjects] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [tutors, setTutors] = useState([]);
  const [isModalOpen, setModal] = useState(false)
  const [selectedSubject, selectSubject] = useState("");
  const [selectedDayIndex, setDayIndex] = useState(-1);
  const [selectedTutors, selectTutors] = useState([]);

  const func = () => {
      fetch(import.meta.env.VITE_BACKEND + "/api/course")
      .then(res => res.json())
      .then(data => {
          setSubjects(data);
          fetch(import.meta.env.VITE_BACKEND + "/api/display/session")
          .then(res => res.json())
          .then(data2 => {
            setSessions(data2);
            fetch(import.meta.env.VITE_BACKEND + "/api/tutor")
            .then(res => res.json())
            .then(data => {
              console.log(data);
              for (let i = 0; i < data.length; i++) {
                console.log(data[i])
                console.log(getDayOfWeekFromDDMMYY(formatDate(0)) ,isTutorWorkToday(data[i].availability, formatDate(0)))
                console.log(getDayOfWeekFromDDMMYY(formatDate(1)) ,isTutorWorkToday(data[i].availability, formatDate(1)))
                console.log(getDayOfWeekFromDDMMYY(formatDate(2)) ,isTutorWorkToday(data[i].availability, formatDate(2)))
              }

              setTutors(data);
              setLoading(false);
            })
          })
      })
  }

  useEffect(() => {
    const sessionId = sessionStorage.getItem("userId");
    if (sessionId == null) {
      navigate('/welcome');
    } else {
      if (sessionId != props.userdata.userId) {
        fetch("http://localhost:8081/api/get_userdata_by_id/" + sessionId)
        .then(res => res.json())
        .then(data => {
          if (data.length == 1) {
            props.setUserdata({
                ...props.userdata,
                userId: data[0].userId,
                role: data[0].userRole,
                fname: data[0].firstName,
                mname: data[0].middleName,
                lname: data[0].lastName
            });
          }
        })
      }
      func();
    }
  }, [isModalOpen])

  useEffect(() => {

  }, [loading, isModalOpen])

  const headers = ["Today", "Tomorrow", "The day after tomorrow"];

  const formatDate = (offset) => {
        const today = new Date();
        today.setDate(today.getDate() + offset);
        const day = String(today.getDate()).padStart(2, '0');
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const year = String(today.getFullYear()).slice(-2)
        return `${day}${month}${year}`;
  }

  const openModal = (sid, i) => {
    setModal(true);
    selectSubject(sid);
    setDayIndex(i);
    console.log(sid + " " + i);
  }

  function getDayOfWeekFromDDMMYY(dateString) {
    const day = parseInt(dateString.substring(0, 2), 10);
    const month = parseInt(dateString.substring(2, 4), 10) - 1; // Month is 0-based in JavaScript
    const year = 2000 + parseInt(dateString.substring(4, 6), 10); // Assuming years are in 21st century
    const date = new Date(year, month, day);
  
    return date.getDay();
  }

  function isTutorWorkToday(avai, date) {
    let day = getDayOfWeekFromDDMMYY(date) - 1
    if (day < 0 || day > 4)
      return false;
    if (avai.at(day) == 'F')
      return false;
    return true;
  }

  const handleCheckboxChange = (tid) => {
    if (selectedTutors.includes(tid)) {
      selectTutors(selectedTutors.filter(item => item !== tid));
    } else {
      selectTutors([...selectedTutors, tid]);
    }
  }

  const handleSave = () => {
    const id = (sessions.filter(item => item.sessionId.endsWith(formatDate(selectedDayIndex))).length + 1).toString().padStart(2, '0') + formatDate(selectedDayIndex);
    const data = {
      sid: id,
      st: selectedTutors,
      subid: selectedSubject
    }
    if (data.st < 1) {
      return;
    }
    setModal(false);
    fetch(import.meta.env.VITE_BACKEND + "/api/insert_tutor_session/" + JSON.stringify(data))
  }

  return (
    <>
      <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
      {
        !loading ?
        <div>
            <br />
          {
           <div>
           <table className="timetable">
            <thead>
                <tr>
                    <th >Subject</th>
                    {
                        headers.map((header, index) => (
                            <th key={index}>{header}</th>
                        ))
                    }
                </tr>
            </thead>
            <tbody>
                {
                    subjects.map((subject, si) => (
                        <tr key={si}>
                            <td>{subject.subjectName}</td>
                            {
                                headers.map((header, index) => (
                                    <td key={index}>
                                        {
                                            sessions.filter(item => item.sessionId.endsWith(formatDate(index)) && item.subjectId == subject.subjectId).map((s, i) => (
                                                <div key={i}>
                                                    <h6>{s.sessionId}</h6>
                                                    <h6>{s.tutors}</h6>
                                                </div>
                                            ))
                                        }
                                        {
                                          props.userdata.role == "student"  || props.userdata.role == "tutor" ?
                                          <div />
                                          :
                                          <button onClick={() => openModal(subject.subjectId, index)}>Insert</button>
                                        }
                                        
                                    </td>
                                ))
                            }
                        </tr>
                    ))
                }
           </tbody>
           </table>
           </div>
          }

          {isModalOpen && (
            <div className="modal">
              <div className="modal-content">
                <h2>{"Insert Tutor"}</h2>
                <label>Tutor:</label><br />
                {
                  tutors.filter(item => isTutorWorkToday(item.availability, formatDate(selectedDayIndex))).map((t, i) => (
                    <div key={i}>
                      <label>
                        <input 
                          type="checkbox"
                          checked={selectedTutors.includes(t.tutorId)}
                          onChange={() => handleCheckboxChange(t.tutorId)}
                        />
                        {t.tutorId} - {t.firstName}
                      </label>
                    </div>
                  ))
                }
                <button className="save-button" onClick={handleSave}>Save</button>
                <button className="save-button" onClick={() => setModal(false)}>Close</button>
              </div>
            </div>
          )}
        </div>
        :
        <div />
      }
      <Footer />
    </> 
  );
}

export default Timetable;
