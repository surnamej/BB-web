import React, { useEffect, useState } from 'react';
import Footer from './components/Footer';
import Menu from './components/Menu';
import './App.css';
import { useNavigate } from 'react-router-dom';

function Profile(props) {
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    const sessionId = sessionStorage.getItem("userId");
    if (sessionId == null) {
      navigate('/welcome');
    } else {
      if (sessionId != props.userdata.userId) {
        fetch("http://localhost:8081/api/get_userdata_by_id/" + sessionId)
        .then(res => res.json())
        .then(data => {
          if (data.length == 1) {
            props.setUserdata({
                ...props.userdata,
                userId: data[0].userId,
                role: data[0].userRole,
                fname: data[0].firstName,
                mname: data[0].middleName,
                lname: data[0].lastName
            });
            setLoading(false);
          }
        })
      }
      setLoading(false);
    }
    if (props.userdata.role == "admin") navigate("/user_display");
  }, [])

  useEffect(() => {

  }, [loading])

  return (
    <div>
      <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
      {
        loading ?
        <div />
        :
        <div className="student-profile-container">
          <h2 className="fancy-heading">Welcome, {props.userdata.fname} <span className="wave">👋</span> </h2>
          <div className="profile-section">
            <h3>General Information</h3>
            <p><span className="info-label">Name:</span> {props.userdata.fname} {props.userdata.lname}</p>
          </div>
        </div>
      }
      <Footer />
    </div>
  );
}

export default Profile;