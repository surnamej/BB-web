import React, { useEffect, useState } from "react";
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button';
import './App.css'
import { useNavigate } from "react-router-dom";

function Login(props) {
    const navigate = useNavigate();
    const [userId, setUserId] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(true);

    const clickHandle = () => {
        console.log(import.meta.env.VITE_BACKEND + "/api/get_userdata/" + userId + "/" + password)
        if (userId != "" && password != "") {
            fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata/" + userId + "/" + password)
            .then(res => res.json())
            .then(data => {
                if (data.length == 1) {
                    props.setUserdata({
                        ...props.userdata,
                        userId: data[0].userId,
                        role: data[0].userRole,
                        fname: data[0].firstName,
                        mname: data[0].middleName,
                        lname: data[0].lastName
                    });
                    sessionStorage.setItem("userId", data[0].userId);
                    switch (data[0].userRole) {
                        case "student": 
                            navigate("/home");
                            break;
                        case "tutor":
                            navigate("/course");
                            break;
                        case "admin":
                            navigate("/data");
                            break;
                    }
                } else {
                    window.alert("Incorrect")
                    document.getElementById("userId").value = "";
                    document.getElementById("password").value = "";
                }
            })
        }
    }

    useEffect(() => {
        if (sessionStorage.getItem("userId") == null) {
            setLoading(false);
        }
        else {
            fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionStorage.getItem("userId"))
            .then(res => res.json())
            .then(data => {
                if (data.length == 1) {
                    props.setUserdata({
                        ...props.userdata,
                        userId: data[0].userId,
                        role: data[0].userRole,
                        fname: data[0].firstName,
                        mname: data[0].middleName,
                        lname: data[0].lastName
                    });
                    sessionStorage.setItem("userId", data[0].userId);
                    switch (data[0].userRole) {
                        case "student": 
                            navigate("/home");
                            break;
                        case "tutor":
                            navigate("/course");
                            break;
                        case "admin":
                            navigate("/data");
                            break;
                    }
                }
            });
        }
    }, [])

    return (
        <>
        {
            !loading ? 
            <Container fluid className="login-container">
                <Row lg={"auto"}>
                    <Col lg={"auto"}>
                        <div className="auth-form-div">
                            <h2>Login</h2>
                            <form className="login-form needs-validation">
                                <div className="login-group form-group was-validated">
                                    <label className="login-form-label form-label" htmlFor="userid">User ID</label>
                                    <input className="login-input form-control" required onChange={e => setUserId(e.target.value)} type="text" placeholder="12345" id="userId" name="userId" />
                                    <div className="valid-feedback"></div>
                                    <div className="invalid-feedback">Please enter your user ID</div>
                                </div>
                                <div className="login-group form-group was-validated mb-2">
                                    <label className="login-form-label form-label" htmlFor="password">password</label>
                                    <input className="login-input form-control" required onChange={e => setPassword(e.target.value)} type="password" placeholder="********" id="password" name="password"/>
                                    <div className="valid-feedback"></div>
                                    <div className="invalid-feedback">Please enter your password</div>
                                </div>
                                <Button className="login-button btn-secondary block p-auto my-3" onClick={clickHandle}>Log In</Button>
                            </form>
                        </div>
                    </Col>
                </Row>
            </Container>
            : 
            <div />
        }
        </>
    )
}

export default Login;