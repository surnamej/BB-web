import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css'; // Import your CSS file
import Footer from './components/Footer';
import Menu from './components/Menu';

function FormPage(props) {
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const [subjects, setSubjects] = useState([]);

    const func = () => {
        fetch(import.meta.env.VITE_BACKEND + "/api/course")
        .then(res => res.json())
        .then(data => {
            setSubjects(data);
            console.log(data);
            setLoading(false);
        })
    }

    useEffect(() => {
        const sessionId = sessionStorage.getItem("userId");
        if (sessionId == null) {
            navigate('/welcome');
        } else {
            if (sessionId != props.userdata.userId) {
                fetch(import.meta.env.VITE_BACKEND + "/api/get_userdata_by_id/" + sessionId)
                .then(res => res.json())
                .then(data => {
                    if (data.length == 1) {
                        props.setUserdata({
                            ...props.userdata,
                            userId: data[0].userId,
                            role: data[0].userRole,
                            fname: data[0].firstName,
                            mname: data[0].middleName,
                            lname: data[0].lastName
                        });
                    }
                })
            }
            func();
        }
        if (props.userdata.role == "student") navigate("/home");
        if (props.userdata.role == "tutor") navigate("/course");
    }, [])

    useEffect(() => {

    }, [loading])

    const [user, setUser] = useState({
        password: "",
        fname: "",
        mname: "",
        lname: "",
        role: "student",
        subjects: [],
        availability: []
    })

    const handleCheckboxChange = (subject) => {
        if (user.subjects.includes(subject)) {
          setUser({
            ...user,
            subjects: user.subjects.filter((item) => item !== subject)
          })
        } else {
          setUser({
            ...user,
            subjects: [...user.subjects, subject]
          })
        }
    }

    const handleDayChange = (day) => {
        if (user.availability.includes(day)) {
          setUser({
            ...user,
            availability: user.availability.filter((item) => item !== day)
          })
        } else {
          setUser({
            ...user,
            availability: [...user.availability, day]
          })
        }
    }

    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

    const validateName = (name) => {
        const nameRegex = /^[a-zA-Z]+$/;
        return name.match(nameRegex);
    };

    const handleRegistration = () => {
        if (!validateName(user.fname)) {
            alert('Invalid first name. Please enter only letters.');
            return;
        }

        if (!validateName(user.lname)) {
            alert('Invalid last name. Please enter only letters.');
            return;
        }

        if (user.availability.length == 0 && user.role == "tutor") {
            alert('Invalid availability. Please select at least 1 day.');
            return;
        }

        if (user.subjects.length == 0 && user.role == "tutor") {
            alert('Invalid subject. Please select at least 1 subject.');
            return;
        }
        let newAvai = ""
        for (let i = 0; i < 5; i++) {
            if (user.availability.includes(i)) {
                newAvai += 'T'
            } else {newAvai += "F"}
        }
        fetch(import.meta.env.VITE_BACKEND + "/api/insert_user/" + JSON.stringify(user) + "/" + newAvai)
    };

    const validatePassword = () => {
        const passwordRegex = /^@([a-zA-Z]+)123$/;
        return password.match(passwordRegex);
    };

    return (
        <>
            <Menu userdata={props.userdata} setUserdata={props.setUserdata}/>
            {
                !loading ?
                <div className="registration-form">
                    <h2>Registration</h2>
                    <form>
                        <div>
                            <label>First Name:</label>
                            <input
                                type="text"
                                value={user.fname}
                                onChange={(e) => setUser({
                                    ...user,
                                    fname: e.target.value
                                })}
                            />
                        </div>
                        <div>
                            <label>Middle Name:</label>
                            <input
                                type="text"
                                value={user.mname}
                                onChange={(e) => setUser({
                                    ...user,
                                    mname: e.target.value
                                })}
                            />
                        </div>
                        <div>
                            <label>Last Name:</label>
                            <input
                                type="text"
                                value={user.lname}
                                onChange={(e) => setUser({
                                    ...user,
                                    lname: e.target.value
                                })}
                            />
                        </div>
                        <div>
                            <label>Password:</label>
                            <input
                                type="password"
                                value={user.password}
                                onChange={(e) => setUser({
                                    ...user,
                                    password: e.target.value
                                })}
                            />
                        </div>
                        <div>
                            <label>User Role:</label>
                            <label>
                                <input
                                type="radio"
                                value="student"
                                checked={user.role === 'student'}
                                onChange={() => setUser({
                                    ...user,
                                    role: 'student'
                                })}
                                />
                                Student
                            </label>
                            <label>
                                <input
                                type="radio"
                                value="tutor"
                                checked={user.role === 'tutor'}
                                onChange={() => setUser({
                                    ...user,
                                    role: 'tutor'
                                })}
                                />
                                Tutor
                            </label>
                        </div>
                        {user.role === 'tutor' && (
                            <>
                                <h3>Subjects to Teach</h3>
                                {subjects.map(subject => (
                                    <div key={subject.subjectId}>
                                        <label>
                                            <input
                                                type="checkbox"
                                                checked={user.subjects.includes(subject.subjectId)}
                                                onChange={() => handleCheckboxChange(subject.subjectId)}
                                            />
                                            {subject.subjectName}
                                        </label>
                                    </div>
                                ))}
                                <h3>Availability</h3>

                                {days.map((day, index) => (
                                    <div key={index}>
                                        <label>
                                        <input
                                            type="checkbox"
                                            checked={user.availability.includes(index)}
                                            onChange={(e) => handleDayChange(index)}
                                        />
                                        {day}
                                        </label>
                                    </div>
                                ))}
                            </>
                        )}
                        <button type="button" onClick={handleRegistration}>
                            Register
                        </button>
                    </form>
                    <br />
                </div>
                :
                <div />
            }
            <Footer />
        </>
        
    );
}

export default FormPage;
