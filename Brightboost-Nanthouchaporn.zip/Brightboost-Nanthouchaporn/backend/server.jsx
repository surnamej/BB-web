const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");

const app = express();
app.use(cors());

const pool = mysql.createPool({
    host: "bszyuqgcxp5bsimfl01y-mysql.services.clever-cloud.com",
    user: "uxruwcan06tupcgn",
    password: "imKwTeq5rBhpb7xB3uMP",
    database: "bszyuqgcxp5bsimfl01y",
    port: 20110
})

app.get("/api/get_userdata_by_id/:id", (req, res) => {
    const sql = "SELECT u.userId, u.userRole, u.firstName, u.middleName, u.lastName FROM bb_user as u WHERE u.userId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.id], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/get_userdata/:id/:pass", (req, res) => {
    const sql = "SELECT u.userId, u.userRole, u.firstName, u.middleName, u.lastName FROM bb_user as u WHERE u.userId = ? AND u.password = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.id, req.params.pass], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    });
});

app.get("/api/course", (req, res) => {
    const sql = "SELECT * FROM bb_subject";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/course_by_tutor/:id", (req, res) => {
    const sql = "SELECT s.subjectId as subjectId, s.subjectName as subjectName " +
                "FROM bb_tutor as t JOIN bb_teaching_subject as ts ON t.tutorId = ts.tutorId " +
                "JOIN bb_subject as s ON ts.subjectId = s.subjectId WHERE t.tutorId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.id], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/tutor_availability/:id", (req, res) => {
    const sql = "SELECT t.availability FROM bb_tutor as t WHERE t.tutorId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.id], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/tutor_in_session/:sessionId", (req, res) => {
    const sql = "SELECT u.userId, CONCAT(u.firstName, ' ', u.middleName, ' ', u.lastName) AS name FROM bb_user as u " +
                "JOIN bb_tutor_session as t ON t.tutorId = u.userId " +
                "WHERE t.sessionId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.sessionId], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/course_check/:subjectId", (req, res) => {
    const sql = "SELECT COUNT(*) AS count FROM bb_subject as s WHERE s.subjectId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.subjectId], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/question_by_session/:sessionId", (req, res) => {
    const sql = "SELECT q.questionId, q.studentId, q.questionText, q.answerText FROM bb_question as q WHERE q.sessionId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.sessionId], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/question_by_id/:question", (req, res) => {
    const sql = "SELECT * FROM bb_question as q WHERE q.questionId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.question], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("api/tutor_question/:tutor", (req, res) => {
    const sql = "SELECT q.questionId, q.studentId, q.questionText, q.answerText FROM bb_question as q WHERE q.tutorId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.sessionId], async (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

const getFormattedDate = (full = true) => {
    const currentDate = new Date();
    const options = 
        full ?
            { year: '2-digit', month: '2-digit', day: '2-digit' }
            :
            { year: '2-digit', month: '2-digit' }
    
    return currentDate.toLocaleDateString('en-GB', options).replace(/\//g, '');
}

app.get("/api/session/:subjectId", (req, res) => {
    const sql = "SELECT s.sessionId FROM bb_session as s WHERE s.sessionId LIKE \"%" + getFormattedDate() + "\" AND s.subjectId = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.subjectId], (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/session/:subjectId/:tutorId", (req, res) => {
    const sql = "SELECT s.sessionId FROM bb_session as s JOIN bb_tutor_session as ts ON s.sessionId = ts.sessionId " + 
                "WHERE s.sessionId LIKE \"%" + 
                getFormattedDate() + "\" AND ts.tutorId = ? " + " AND s.subjectId = ?"
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.tutorId, req.params.subjectId], (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

// DATA DISPLAY
app.get("/api/display/user_info", (req, res) => {
    const sql = "SELECT u.userId, u.firstName, u.middleName, u.lastName, u.userRole FROM bb_user AS u";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/display/session", (req, res) => {
    const sql = "SELECT s.subjectId, s.sessionId, " +
                "GROUP_CONCAT(CONCAT(u.firstName, ' ', u.middleName, ' ', u.lastName) SEPARATOR ', ') as tutors, " + 
                "s.attendance, " + 
                "(SELECT COUNT(*) FROM bb_question q WHERE q.sessionId = s.sessionId) AS question_count " +
                "FROM bb_session s " +
                "JOIN bb_tutor_session ts ON s.sessionId = ts.sessionId " +
                "JOIN bb_user u ON ts.tutorId = u.userId " +
                "GROUP BY s.sessionId";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

app.get("/api/display/question", (req, res) => {
    const sql = "SELECT q.sessionId, " +
                "q.questionText, " +
                "q.answerText, " +
                "q.tutorId, " +
                "TIMESTAMPDIFF(SECOND, q.timestamp, q.answerTime) as time " +
                "FROM bb_question as q;"
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })           
})

app.get("/api/dashboard/general", (req, res) => {
    const sql = "SELECT (SELECT COUNT(*) FROM bb_student) as students, " + 
                "(SELECT COUNT(*) FROM bb_question) as questions, "+ 
                "(SELECT COUNT(*) FROM bb_question as q WHERE q.answerText IS NOT NULL) as answers"
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })  
})

app.get("/api/dashboard/monthly", (req, res) => {
    const sql = "SELECT s.subjectId, SUM(s.attendance) as students FROM bb_session as s WHERE s.sessionId LIKE ? GROUP BY s.subjectId"
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, ['%' + getFormattedDate(false)], (error, data) => {
            connection.release();
            if (error) return res.json(error);
            return res.json(data);
        })
    })
})

// INSERT
const numberToString = (number, letter) => {
    return number.toString().padStart(letter, '0');
}

app.get("/api/insert_question/:text/:student/:tutor/:session", (req, res) => {
    const countSql = "SELECT COUNT(*) as count FROM bb_question";
    const sql = "INSERT INTO bb_question (questionId, questionText, studentId, tutorId, sessionId, timestamp) " + 
                "VALUES (?, ?, ?, ?, ?, CURRENT_TIME())"
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(countSql, (error, data) => {
            if (error) return res.json(error);
            let id = 'Q' + numberToString(data[0].count + 1, 5);
            connection.query(sql, [id, req.params.text, req.params.student, req.params.tutor, req.params.session], (e) => {
                connection.release()
                if (e) return res.json(e);
                return res.json("Complete");
            })
        })
    })
})

app.get("/api/insert_user/:json/:avai", (req, res) => {
    const userdata = JSON.parse(req.params.json)
    console.log(userdata)
    switch (userdata.role) {
        case "student": {
            const countSql = "SELECT COUNT(*) as count FROM bb_student";
            const sql = "INSERT INTO `bb_user` (`userId`, `password`, `userRole`, `firstName`, `middleName`, `lastName`) VALUES (?, ?, 'student', ?, ?, ?)"
            const sql2 = "INSERT INTO `bb_student` (`studentId`, `paymentStatus`, `enroleDate`) VALUES (?, '0', CURRENT_TIMESTAMP)"
            pool.getConnection(async (err, connection) => {
                connection.query(countSql, (error, data) => {
                    let id = 'S' + numberToString(data[0].count + 1, 4);
                    connection.query(sql, [id, userdata.password, userdata.fname, userdata.mname, userdata.lname], (e1) => {
                        connection.query(sql2, [id], (e2) => {
                            connection.release();
                            return;
                        })
                    })
                })
            })
            break;
        }
        case "tutor" : {
            const countSql = "SELECT COUNT(*) as count FROM bb_tutor";
            const sql = "INSERT INTO `bb_user` (`userId`, `password`, `userRole`, `firstName`, `middleName`, `lastName`) VALUES (?, ?, 'tutor', ?, ?, ?)"
            const sql2 = "INSERT INTO `bb_tutor` (`tutorId`, `availability`) VALUES (?, ?)"
            const sql3 = "INSERT INTO `bb_teaching_subject` (`tutorId`, `subjectId`) VALUES (?, ?)";
            pool.getConnection(async (err, connection) => {
                connection.query(countSql, (e1, d1) => {
                    let id = 'T' + numberToString(d1[0].count + 1, 4);
                    connection.query(sql, [id, userdata.password, userdata.fname, userdata.mname, userdata.lname], (e2) => {
                        connection.query(sql2, [id, req.params.avai], (e3) => {
                            if (e3) {
                                console.log(e3)
                            } else {
                                console.log(userdata.subjects);
                                for (const sid in userdata.subjects) {
                                    connection.query(sql3, [id, userdata.subjects[sid]], e4 => {
                                        connection.release();
                                        return;
                                    })
                                }
                            }
                        })
                    })
                })
            })
            break;
        }

    }
})

// UPDATE
app.get("/api/update/answering/:question/:text", (req, res) => {
    const sql = "UPDATE `bb_question` SET `answerText` = ?, `answerTime` = CURRENT_TIME() WHERE `bb_question`.`questionId` = ?";
    pool.getConnection(async (err, connection) => {
        if (err) return res.json(err);
        connection.query(sql, [req.params.text, req.params.question], (error, data) => {
            if (error) return res.json(error);
            return res.json("Update");
        })
    })
})

app.get("/api/attendance/:number/:session", (req, res) => {
    const sql = "UPDATE bb_session SET attendance = ? WHERE bb_session.sessionId = ?;"
    pool.getConnection(async (err, connection) => {
        if (err) {
            console.log(err)
            return;
        } else {
            connection.query(sql, [req.params.number, req.params.session], (error) => {
                if (error) console.log(error)
            })
        }
    })
})

app.get("/api/tutor", (req, res) => {
    const sql = "SELECT u.firstName, t.tutorId, t.availability FROM bb_tutor as t JOIN bb_user as u ON u.userId = t.tutorId";
    pool.getConnection(async (err, connection) => {
        if (err) {
            console.log(err)
            return;
        } else {
            connection.query(sql, (error, data) => {
                connection.release();
                if (error) return res.json(error);
                return res.json(data);
            })
        }
    })
})

app.get("/api/insert_tutor_session/:json", (req, res) => {
    const ssql = "INSERT INTO `bb_session` (`sessionId`, `subjectId`, `attendance`) VALUES (?, ?, '0')"
    const sql = "INSERT INTO `bb_tutor_session` (`tutorId`, `sessionId`) VALUES (?, ?)";
    const ts = JSON.parse(req.params.json);
    console.log(ts);
    pool.getConnection(async (err, connection) => {
        if (err) {
            console.log(err);
            return;
        } else {
            connection.query(ssql, [ts.sid, ts.subid], err1 => {
                if (err1) console.log(err1)
                for (let i = 0; i < ts.st.length; i++) {
                    connection.query(sql, [ts.st[i], ts.sid], err => {
                        if (err) console.log(err)
                        connection.release();
                    })
                }
            })
        }
    })
})

app.get("/", (req, res) => {
    return res.json("This is API:" + getFormattedDate());
})

app.listen(8081, () => {
    console.log("db available");
})