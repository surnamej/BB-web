# Brightboost
## Pages
```
index.html as a Home page
```
